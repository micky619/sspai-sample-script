#!/bin/bash

osascript -e 'display notification "yooo" with title "套壳截图完成" sound name "Submarine"'
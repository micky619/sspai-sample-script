#!/bin/bash

osascript -e 'display notification "yooo" with title "添加阴影完成" sound name "Submarine"'
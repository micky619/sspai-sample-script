#!/bin/bash

osascript -e 'display notification "yooo" with title "Compressed" sound name "Submarine"'
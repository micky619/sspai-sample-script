#!/usr/bin/env python
#
# LaunchBar Action Script
#
import sys
import subprocess as sp
import os
import json
import shutil

my_env = os.environ.copy()
my_env["PATH"] = "/usr/local/bin:" + my_env["PATH"]
# Note: The first argument is the script's path

newFile = "/Users/apple/Desktop/newfile.png"

args = []
for arg in sys.argv[1:]:
    args.append(arg)

my_command = ["convert"] + args + ["-background", "none", "+append", newFile]

sp.check_output(my_command, env=my_env)
os.system('sh noti.sh')
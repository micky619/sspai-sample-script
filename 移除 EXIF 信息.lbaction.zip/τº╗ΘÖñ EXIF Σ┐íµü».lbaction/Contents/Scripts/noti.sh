#!/bin/bash

osascript -e 'display notification "yooo" with title "已清除 EXIF 信息" sound name "Submarine"'
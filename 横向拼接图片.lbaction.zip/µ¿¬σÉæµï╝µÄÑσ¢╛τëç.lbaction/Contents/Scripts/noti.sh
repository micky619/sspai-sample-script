#!/bin/bash

osascript -e 'display notification "yooo" with title "图片拼接完成" sound name "Submarine"'
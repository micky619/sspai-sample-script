#!/usr/bin/env python
#
# LaunchBar Action Script
#
import sys
import subprocess as sp
import os
import json
import shutil

my_env = os.environ.copy()
my_env["PATH"] = "/usr/local/bin:" + my_env["PATH"]
# Note: The first argument is the script's path

for arg in sys.argv[1:]:
        fileType = (os.path.splitext(arg)[-1]).lower()
        fileFolder = os.path.dirname(arg)
        fileName = os.path.basename(arg)
        newFile = fileFolder + "/new-" + fileName
        if fileType == ".png":
                my_command = ["pngquant", arg, "--quality", "70-95", "--force"]
                sp.check_output(my_command, env=my_env)
        elif fileType == ".jpg" or fileType == ".jpeg":
                shutil.copy(arg,newFile)
                my_command = ["jpegoptim", "-m70", "--max90", newFile] 
                sp.check_output(my_command, env=my_env)
        elif fileType == ".gif":
                my_command = ["gifsicle", "-i", arg, "--optimize=3", "-o", newFile] 
                sp.check_output(my_command, env=my_env)
